function [bits,errors] = ecc_decode(coded,ecc_type,varargin)
% This function decodes a vector of bits (specified as a logical vector of
% 0 (false) and 1 (true)) using the error correcting code type 'ecc_type'
% (and additional arguments). Be sure to use the same ecc_type and
% additional arguments as were used to encode the coded bits, or unexpected
% behavior may result. The 'errors' vector lists whether an error was
% detected for each message. Here are the different codes implemented with
% this function:
%
% ecc_type == 'parity': just strips parity bits and detects errors
%   [bits,errors] = ecc_decode(coded,'parity',M);
%       M = message size
%
% ecc_type == 'redundancy': does "majority vote" error correction and
% reports error if any bits do not match
%   [bits,errors] = ecc_decode(coded,'redundancy',N);
%       N = the number of coded bits per input bit (usually >= 2)
%
% ecc_type == 'Hamming': compute "syndrome" and flips erroneous bit
%   [bits,errors] = ecc_decode(coded,'Hamming',P);
%       P = number of parity bits for each code
%

% do decoding
switch lower(ecc_type)
    case 'parity'
        [bits, errors] = ecc_decode_parity(coded,varargin{1});
    case 'redundancy'
        [bits, errors] = ecc_decode_redundancy(coded,varargin{1});
    case 'hamming'
        [bits, errors] = ecc_decode_Hamming(coded,varargin{1});
    otherwise
        error('Unrecognized error correction type');
end

end

function [bits, errors] = ecc_decode_parity(coded,M)

if M < 1
    error('Message size must be >= 1');
end

Ncoded = length(coded);
Npad = ceil(Ncoded/(M+1))*(M+1)-Ncoded;
coded = [coded(1:end-1);false(Npad,1);coded(end)];
coded = reshape(coded,M+1,[]);

bits = coded(1:end-1,:);
errors = mod(sum(coded,1),2) ~= 0;

bits = reshape(bits(1:end-Npad),[],1);

end

function [bits, errors] = ecc_decode_redundancy(coded,N)

if N < 1
    error('N should be >= 1');
end

coded = reshape(coded,N,[]);
bits = sum(coded,1) >= N/2;
errors = ~(all(coded,1) | all(~coded,1)); % any mismatch

end

function [bits, errors] = ecc_decode_Hamming(coded,P)

if P < 2
    error('Hamming code requires P >= 2');
end

M = 2^P - P - 1;

Ncoded = length(coded);
Npad = ceil(Ncoded/(M+P))*(M+P) - Ncoded;

coded = [coded(1:end-P);false(Npad,1);coded(end-P+1:end)];
coded = reshape(coded,M+P,ceil(Ncoded/(M+P)));

bits = coded(1:M,:);
parities = coded(M+1:end,:);

% construct Hamming code and find syndrome
message_rows = uint64(1:M);
for p = 0:P-1
    message_rows(message_rows >= 2^p) = message_rows(message_rows >= 2^p) + 1;
end

error_rows = zeros(1,ceil(Ncoded/(M+P)));
for p = 1:P
    check_rows = bitget(message_rows,p) > 0;
    error_rows = error_rows + (mod(sum(bits(check_rows,:),1),2) ~= parities(p,:)).*2^(p-1);
end

errors = error_rows > 0;

% go back from error row to message row
for p = P-1:-1:0
    error_rows(error_rows == 2^p) = 0; % parity bits don't need to actually be corrected since they don't appear in the output
    error_rows(error_rows > 2^p) = error_rows(error_rows > 2^p) - 1;
end

error_inds = sub2ind([M,ceil(Ncoded/(M+P))],error_rows(error_rows > 0),find(error_rows > 0));
bits(error_inds) = ~bits(error_inds); % correct error bits

% get rid of extra message bits that were padded
bits = reshape(bits(1:end-Npad),[],1);

end
