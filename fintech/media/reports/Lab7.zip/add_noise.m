function signal = add_noise(signal,SNR)
% adds random Gaussian noise with a SNR level in dB, which results in
% random bit errors

std = 10^(-SNR/20);
noise = std.*randn(size(signal));
signal(noise >= 0.5) = ~signal(noise >= 0.5);

end
