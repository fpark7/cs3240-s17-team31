function img = bits_to_grayimage(bits,img_size,img_class)
% recover grayscale image of size img_size pixels with integer data type
% img_class 

Nbits = 8*length(typecast(cast(0,img_class),'uint8')); % get # of bits in data type

bits = reshape(bits,Nbits,[]);
img = zeros(img_size,img_class);

for ibit = 1:Nbits
    img(bits(ibit,:)) = img(bits(ibit,:)) + 2^(ibit-1);
end


end
