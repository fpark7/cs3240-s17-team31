function bits = grayimage_to_bits(img)
% construct a vector of bits from a grayscale image (integer type, *not*
% double type)

if ~isinteger(img), error('Image input is not an integer type. Cast to integer or unsigned integer first.'); end

[sx,sy] = size(img);
img = img(:);
Nbit = 8*length(typecast(img(1),'uint8'));
bits = false(Nbit,length(img));
for ibit = 1:Nbit
    bits(ibit,:) = bitget(img,ibit);
end

% bits = reshape(bits, sx, sy, 8);

end
