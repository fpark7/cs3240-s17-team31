function coded = ecc_encode(bits,ecc_type,varargin)
% This function encodes a vector of bits (specified as a string or as a
% logical vector of 0 (false) and 1 (true)) using the error correcting code
% type 'ecc_type' (and additional arguments). Here are the different codes
% implemented with this function:
%
% ecc_type == 'parity': parity checking with one additional bit for each
% message
%   coded = ecc_encode(bits,'parity',M);
%       M = message size
%
% ecc_type == 'redundancy': repeats each bit N times
%   coded = ecc_encode(bits,'redundancy',N);
%       N = the number of coded bits per input bit (usually >= 2)
%
% ecc_type == 'Hamming': constructs (2^P-1,P) Hamming code for each group
% of 2^P-P-1 message bits with P parity bits (requires P >= 2)
%   coded = ecc_encode(bits,'Hamming',P);
%       P = number of parity bits for each code
%

% convert string to logical bits if needed
if ischar(bits)
    bits = bits(bits == '0' | bits == '1'); % get rid of non 0/1 characters
    bits = (bits == '1');
end
bits = bits(:); % output will be a single column

% do encoding
switch lower(ecc_type)
    case 'parity'
        coded = ecc_encode_parity(bits,varargin{1});
    case 'redundancy'
        coded = ecc_encode_redundancy(bits,varargin{1});
    case 'hamming'
        coded = ecc_encode_Hamming(bits,varargin{1});
    otherwise
        error('Unrecognized error correction type');
end

end

function coded = ecc_encode_parity(bits,M)

if M < 1
    error('Message size must be >= 1');
end

Nbits = length(bits);
Npad = ceil(Nbits/M)*M-Nbits;
bits(end+1:end+Npad) = 0;
bits = reshape(bits,M,[]);

parities = mod(sum(bits,1),2) == 1;

coded = [bits;parities];
coded = reshape(coded([1:end-1-Npad,end]),[],1);

end

function coded = ecc_encode_redundancy(bits,N)

if N < 1
    error('N should be >= 1');
end

coded = reshape(repmat(bits.',N,1),length(bits)*N,1);

end

function coded = ecc_encode_Hamming(bits,P)

if P < 2
    error('Hamming code requires P >= 2');
end

M = 2^P - P - 1;

Nbits = length(bits);
Npad = ceil(Nbits/M)*M-Nbits;
bits(end+1:end+Npad) = 0; % pad end of last message with 0's if needed
bits = reshape(bits,M,ceil(Nbits/M));

% construct Hamming code and find parity bits
message_rows = uint64(1:M);
for p = 0:P-1
    message_rows(message_rows >= 2^p) = message_rows(message_rows >= 2^p) + 1;
end

parities = false(P,ceil(Nbits/M));

for p = 1:P
    check_rows = bitget(message_rows,p) > 0;
    parities(p,:) = mod(sum(bits(check_rows,:),1),2) == 1;
end

coded = [bits;parities];
coded = reshape(coded([1:end-P-Npad,end-P+1:end]),[],1); % get rid of extra message bits

end
